import styles from './MainHeader.module.css';

const MainHeader = () => {
    return (
        <header className={styles.header}>
            <div className={styles.absLogo}>
                <img src="" alt="AlbertsonsLogo" />
            </div>
            <div className={styles.profile}>
                Profile
            </div>
        </header>
    )

}

export default MainHeader;