import MainHeader from "./layout/MainHeader";
import MainNavigation from "./layout/MainNavigation";
import { Route, Switch } from "react-router";
import routes from "./routes/rotes";

import './App.css';

const App = () => {

  return (
    <div className="grid">
      <MainHeader />
      <MainNavigation />
      <main className="main">
        <Switch>
                { routes.map((route, index) => {
                  return <Route key={index} {...route} />
                })}
        </Switch>
      </main>
    </div>
  )

}

export default App;