export const dashboard = [
    {
        id:1,
        category: "AD Groups",
        count: 50
    },
    {
        id:2,
        category: "Profiles",
        count: 200
    },
    {
        id:3,
        category: "Filekeys",
        count: 500
    },
    {
        id:4,
        category: "Fields",
        count: 700
    },
    {
        id:5,
        category: "Applications",
        count: 300
    },
    {
        id:6,
        category: "Screens",
        count: 100
    },
    {
        id:7,
        category: "Users",
        count: 3000
    },
    {
        id:8,
        category: "Filekey Roles",
        count: 150
    },
];