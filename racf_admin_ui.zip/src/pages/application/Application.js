import styles from './Application.module.css';
import { Fragment } from 'react';

const Application = () => {
    return (

        <Fragment>
            <div className={styles.appSubHeader}>
                <div> List of Applications  </div>
                <div className={styles.selectbox}> 
                    <select>
                        <option>
                            Excel
                        </option>
                        <option>
                            PDF
                        </option>
                    </select>
                </div>
            </div>
            <div className={styles.searchbar}>
                <div>Search</div>
                <div>Sort</div>
                <div>Application code</div>
                <div></div>
                <div>Create Application</div>
                <div>Delete Application</div>
            </div>
            <div className={styles.appGrid}>
                <div className={styles.appGridHeader}>
                    <div>
                        Checkbox
                    </div>

                    <div>
                        Application Code
                    </div>

                    <div>Applicatin Description</div>

                    <div>Actions</div>

                </div>
                <div className={styles.appGridRow}>

                    <div>
                        Checkbox
                    </div>

                    <div>
                        Application Code
                    </div>

                    <div>Applicatin Description</div>

                    <div>Actions</div>

                </div>

            </div>
            <div className={styles.pagination}>
                    <div>
                        
                    </div>

                    <div>dropdown</div>

                    <div>Pagination</div>
            </div>
        </Fragment>
    )

}

export default Application;